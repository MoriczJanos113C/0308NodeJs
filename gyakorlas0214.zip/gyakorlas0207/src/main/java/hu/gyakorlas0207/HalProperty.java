package hu.gyakorlas0207;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Validated
@ConfigurationProperties(prefix = "hal")
@PropertySource(value="classpass: application.properties", encoding = "utf-8")
public class HalProperty {
    private @Min(10) @Max(100) @Getter @Setter Integer size;
    private @Getter @Setter String name;

}