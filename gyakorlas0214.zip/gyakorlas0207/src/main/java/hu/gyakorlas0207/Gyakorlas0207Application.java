package hu.gyakorlas0207;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gyakorlas0207Application {

	public static void main(String[] args) {
		SpringApplication.run(Gyakorlas0207Application.class, args);
	}




}
