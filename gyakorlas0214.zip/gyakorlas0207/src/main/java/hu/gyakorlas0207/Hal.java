package hu.gyakorlas0207;

import org.springframework.stereotype.Component;

@Component
public class Hal {
    public Hal(int a) {
    }

    public Hal() {
    }
}