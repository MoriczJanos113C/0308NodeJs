package hu.gyakorlas0207;

public class FishermanEvent {



}
